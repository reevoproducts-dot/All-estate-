LAAZIZA IMMO — projet Android natif hors ligne
- Java Android natif, sans navigateur ni WebView.
- Aucune permission INTERNET dans le manifeste.
- SQLite local: clients, rendez-vous et demandes.
- Rendez-vous: contrôle de chevauchement et plage horaire 08:00–20:00.
- Statuts: En cours / Réussie / Annulée.

Pour compiler l'APK:
1) Ouvrir le dossier LaazizaImmo-Android dans Android Studio.
2) Laisser Gradle télécharger les composants de compilation sur l'ordinateur.
3) Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
4) APK généré: app/build/outputs/apk/debug/app-debug.apk

Important: l'application installée fonctionne sans Internet. La compilation n'a pas été exécutée ici car Android SDK et Gradle ne sont pas disponibles dans cet environnement. Ce ZIP est le projet source, pas encore un APK installable.
